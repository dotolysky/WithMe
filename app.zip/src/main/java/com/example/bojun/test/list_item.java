package com.example.bojun.test;

/**
 * Created by bojun on 2017-05-02.
 */

public class list_item {
    public String kind;
    public String user;
    public String content;


    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getContent() {
        return content;
    }

    public list_item(String kind, String user, String content) {
        this.user = user;
        this.content = content;
        this.kind = kind;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }



}
