package com.example.bojun.test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

/**
 * Created by bojun on 2017-05-02.
 */

public class MyListAdapter extends BaseAdapter {
    Context context;
    ArrayList<list_item> list_itemArrayList;

    TextView user_TextView ;
    TextView content_TextView;
    TextView kind_TextView;


    @Override
    public int getCount() {
        return this.list_itemArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return list_itemArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null)
        {
            convertView = LayoutInflater.from(context).inflate(R.layout.items,null);
            user_TextView = (TextView)convertView.findViewById(R.id.user_textview);
            content_TextView = (TextView)convertView.findViewById(R.id.content_textview);
            kind_TextView = (TextView)convertView.findViewById(R.id.kind_textview);
        }
        kind_TextView.setText(list_itemArrayList.get(position).getKind());
        user_TextView.setText(list_itemArrayList.get(position).getUser());
        content_TextView.setText(list_itemArrayList.get(position).getContent());

        return convertView;
    }




    public MyListAdapter(Context context, ArrayList<list_item> list_itemArrayList) {
        this.context = context;
        this.list_itemArrayList = list_itemArrayList;
    }
}
