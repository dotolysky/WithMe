package com.example.bojun.test;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Matching_main extends AppCompatActivity {
    public ListView listView;
    MyListAdapter myListAdapter;
    ArrayList<list_item> list_itemArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matching_main);
        listView = (ListView)findViewById(R.id.my_listview);
        ArrayList<list_item> list_itemArrayList = new ArrayList<list_item>();
        list_itemArrayList.add(new list_item("운동","김보준","축구 6명 3PM"));
        list_itemArrayList.add(new list_item("운동","한민구","롤 5명 7PM "));
        list_itemArrayList.add(new list_item("운동","최종혁","피파 2명 2AM"));
        list_itemArrayList.add(new list_item("운동","최민구","농구 4명 9PM"));
        list_itemArrayList.add(new list_item("운동","한종혁","캐치볼 5명 10PM"));
        list_itemArrayList.add(new list_item("운동","장민구","당구 1명 11PM"));
        myListAdapter = new MyListAdapter(Matching_main.this,list_itemArrayList);

        listView.setAdapter(myListAdapter);
    }
}
