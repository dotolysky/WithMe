package com.example.bojun.test;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends Activity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button menu_btn = (Button) findViewById(R.id.menu_move);
        menu_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Menu_main.class);
                startActivity(intent);
            }
        });

        Button matching_btn = (Button) findViewById(R.id.matching_move);
        matching_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Matching_main.class);
                startActivity(intent);
                }
        });

        Button haksa_btn = (Button) findViewById(R.id.school_etc_move);
        haksa_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Haksa_main.class);
                startActivity(intent);
            }
        });

        Button chatting_btn = (Button) findViewById(R.id.chat_move);
        chatting_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Chatting_main.class);
                startActivity(intent);
            }
        });
    }
}
