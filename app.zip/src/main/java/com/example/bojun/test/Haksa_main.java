package com.example.bojun.test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Haksa_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_haksa_main);

        Button score_btn = (Button) findViewById(R.id.score_move);
        score_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Score_haksa.class);
                startActivity(intent);
            }
        });

        Button homework_btn = (Button) findViewById(R.id.homework_move);
        homework_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Homework_haksa.class);
                startActivity(intent);
            }
        });

        Button notice_btn = (Button) findViewById(R.id.notice_move);
        notice_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Notice_haksa.class);
                startActivity(intent);
            }
        });

        Button schoolbus_btn = (Button) findViewById(R.id.schoolbus_move);
        schoolbus_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Schoolbus_haksa.class);
                startActivity(intent);
            }
        });
    }
}
