package com.example.bojun.test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class Chatting_main extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatting_main);

        Button taxi_btn2 = (Button) findViewById(R.id.taxi_chat);
        taxi_btn2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Taxi_chat.class);
                startActivity(intent);
            }
        });
        Button exercise_btn2 = (Button) findViewById(R.id.exercise_chat);
        exercise_btn2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Taxi_chat.class);
                startActivity(intent);
            }
        });
        Button meal_btn2 = (Button) findViewById(R.id.meal_chat);
        meal_btn2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Taxi_chat.class);
                startActivity(intent);
            }
        });
        Button majorting_btn2 = (Button) findViewById(R.id.majorting_chat);
        majorting_btn2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Taxi_chat.class);
                startActivity(intent);
            }
        });





    }
}
